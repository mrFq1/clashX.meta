import{W as a,b4 as m}from"./index-BOYfLmCZ.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
