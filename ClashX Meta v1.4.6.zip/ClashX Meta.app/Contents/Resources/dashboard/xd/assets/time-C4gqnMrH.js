import{W as a,b4 as m}from"./index-DNc1N1Rv.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
