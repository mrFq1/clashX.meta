import{W as a,b2 as m}from"./index-2v-8vYjb.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
